backgroundColor = 0x80808080
borderColor = 0xFF000000
borderColor2 = 0x00000000
white= 0xFFFFFFFF
red = 0xFFFF0000
yellow = 0XFFFFFF00
pink = 0xFFFF69B4
lightblue = 0xFFADD8E6
BoxRadius = 6
boxStartX = 10
boxStartY = 30
boxSide = 70
boxScale = 255/boxSide
marioSpriteSize = 16
enemySpriteSize = 17
marioXGrid = 0
marioYGrid = 0
controller = {}
displayText = ""
StopDoingNothing=0
LastX=0
LastY=0
maxIdleFrame = 10

finished = false


ButtonNames = {
	"A",
	"B",
	"Up",
	"Down",
	"Left",
	"Right",
}

Level1Grid={}
QMap={}



EnemyXPositions = {} 
EnemyYPositions = {} 




function GetMarioPosition()
	--Use readbyte because we only read the lower half for position values
	marioX = memory.read_u8(0x0046)
	marioY = memory.read_u8(0x0047)
	marioStat = memory.read_u8(0x0096)
end

function GetEnemyPositions()
	local xMem = 0x0213
	local yMem = 0x0214
	for i=0, 11 do
		--Use readbyte because we only read the lower half for position values
		EnemyXPositions[i] = memory.readbyte(xMem)
		EnemyYPositions[i] = memory.readbyte(yMem)
		xMem = xMem + 0x0010
		yMem = yMem + 0x0010
	end
end

--General purpose function to draw something in the minimap
function DrawPosInBox(worldX, worldY, col)
    local localX = worldX/boxScale + boxStartX
    local localY = worldY/boxScale + boxStartY
    gui.drawRectangle(localX, localY, 5, 5, borderColor, col)
end

function DrawMapInBox(worldX, worldY, col)
    local localX = worldX/boxScale + boxStartX
    local localY = worldY/boxScale + boxStartY
    gui.drawRectangle(localX, localY, 2, 2, borderColor2, col)
end



function DrawEnemiesInFOV()
	local offset = 3
	local marioCenterX = marioX + offset
	local marioCenterY = marioY + offset

	local maxToTheRight = marioCenterX + marioSpriteSize/2 + marioSpriteSize
	local maxToTheLeft = marioCenterX - marioSpriteSize/2 - marioSpriteSize
	local maxToTheTop = marioCenterY - marioSpriteSize/2 - marioSpriteSize
	local maxToTheBottom = marioCenterY - marioSpriteSize/2

	for i = 0, 11 do
		if EnemyXPositions[i] ~= 255 and EnemyYPositions[i] ~= 255 then
			if EnemyXPositions[i] + offset < maxToTheRight and EnemyXPositions[i] - offset > maxToTheLeft then
				gui.drawRectangle(EnemyXPositions[i], EnemyYPositions[i], 16, 16, borderColor, red)

				-- if EnemyYPositions[i] > maxToTheTop and EnemyYPositions[i] < maxToTheBottom then
				-- 	gui.drawRectangle(EnemyXPositions[i], EnemyYPositions[i], 16, 16, borderColor, red)
				-- end
			end
		end
	end
end


function DrawFOV()
	local offset = 3
	--Around Mario
	gui.drawRectangle(marioX + offset - marioSpriteSize/2, marioY + offset - marioSpriteSize/2, marioSpriteSize, marioSpriteSize, borderColor, backgroundColor)
	--Bottom right
	gui.drawRectangle(marioX + offset - marioSpriteSize/2 - marioSpriteSize, marioY + offset - marioSpriteSize/2, marioSpriteSize, marioSpriteSize, borderColor, backgroundColor)
	--Bottom left
	gui.drawRectangle(marioX + offset - marioSpriteSize/2 + marioSpriteSize, marioY + offset - marioSpriteSize/2, marioSpriteSize, marioSpriteSize, borderColor, backgroundColor)
	--Top right
	gui.drawRectangle(marioX + offset - marioSpriteSize/2 - marioSpriteSize, marioY + offset - marioSpriteSize/2 - marioSpriteSize, marioSpriteSize, marioSpriteSize, borderColor, backgroundColor)
	--Top center
	gui.drawRectangle(marioX + offset - marioSpriteSize/2, marioY + offset - marioSpriteSize/2 - marioSpriteSize, marioSpriteSize, marioSpriteSize, borderColor, backgroundColor)
	--Top left
	gui.drawRectangle(marioX + offset - marioSpriteSize/2 + marioSpriteSize, marioY + offset - marioSpriteSize/2 - marioSpriteSize, marioSpriteSize, marioSpriteSize, borderColor, backgroundColor)
end



function DrawMinimap()
	--Background
	gui.drawRectangle(boxStartX, boxStartY, boxSide, boxSide,borderColor, backgroundColor)
	
	--Hardcoded Map
	for i=0, 49 do
		for j=0, 49 do
			if Level1[i][j] == 1 then
				DrawMapInBox(j*5,i*5, pink)
			end
			if Level1[i][j] == 2 then
				DrawMapInBox(j*5,i*5, lightblue)
			end
        end
    end
	
	
	--Characters - Mario
	DrawPosInBox(marioX, marioY, white)
	--Characters - Enemies
	for i=0, 11 do
        if EnemyXPositions[i] ~= 255 and EnemyYPositions[i] ~= 255 then
            DrawPosInBox(EnemyXPositions[i], EnemyYPositions[i], red)
        end
    end
end


function ReadBoard()
	j=math.floor(marioX/5)
	i=math.floor(marioY/5)
	Level1Grid[i][j] = 1
	QMap[i][j] = -10+StopDoingNothing
	marioXGrid=j
	marioYGrid=i
	for k = 0, 11 do
		if EnemyXPositions[k] ~= 255 and EnemyYPositions[k] ~= 255 then
			j=math.floor((EnemyXPositions[k]+5)/5)
			i=math.floor((EnemyYPositions[k])/5)
			Level1Grid[i-1][j] = 2
			QMap[i-1][j] = -30
			QMap[i-2][j] = 200
			QMap[i-2][j-1] = 200
			QMap[i-2][j+1] = 200
		
		end
	end
	
end

function CalculateNextMove(x,y)
	local j = 0
	local i = 0
	maxValue = -10
	Maxj = 0
	Maxi = 0
	for j = -1, 1 do
		for i = -1, 1 do
		
			if y+i >=1 and y+i <=255 and x+j >=1 and x+j <=255 then
			
				if QMap[y+i][x+j] > maxValue then
					maxValue=QMap[y+i][x+j]
					Maxj=j
					Maxi=i
					displayText ="MaxValue =" .. maxValue .. " " .. "NextMove = " .. j .. " " .. i
				end
				
			end
			
		end
	end
	

	
	if Maxj ==-1 and Maxi == -1 then
		doMove("Up-Left")
	elseif Maxj ==0 and Maxi == -1 then
		doMove("Up")
	elseif Maxj ==1 and Maxi == -1 then
		doMove("Up-Right")
	elseif Maxj ==-1 and Maxi == 0 then
		doMove("Left")
	elseif Maxj ==0 and Maxi == 0 then
		doMove("Stop")
	elseif Maxj ==1 and Maxi == 0 then
		doMove("Right")
	elseif Maxj ==-1 and Maxi == 1 then
		doMove("Down-Left")
	elseif Maxj ==0 and Maxi == 1 then
		doMove("Down")
	elseif Maxj ==1 and Maxi == 1 then
		doMove("Down-Right")
	end
	
end

function doMove(Action)


-- 1
	if Action =="Up-Left" then
	
		controller["P1 Left"] = true
		controller["P1 A"] = true
-- 2		
	elseif Action =="Up" then
	
		controller["P1 Up"] = true
-- 3		
	elseif Action =="Up-Right" then
	
		controller["P1 Right"] = true
		controller["P1 A"] = true
-- 4	
	elseif Action =="Left" then
	
		controller["P1 Left"] = true
-- 5	
	elseif Action =="Stop" then

		controller["P1 Up"] = true
-- 6	
	elseif Action =="Right" then
	
		controller["P1 Right"] = true
	
	elseif Action =="Down-Left" then
		--Do Nothing
-- 7		
	elseif Action =="Down" then
	
		controller["P1 Down"] = true
		
	elseif Action =="Down-Right" then
		--Do Nothing
	else
	print("ERROR, MOVE ' " .. Action .. " ' Not found!!!")
	end
	
	joypad.set(controller)
end

function clearMove()
	controller["P1 Up"] = false
	controller["P1 Down"] = false
	controller["P1 Left"] = false
	controller["P1 Right"] = false
	controller["P1 A"] = false
	controller["P1 B"] = false
end


function saveTable(NameFile,marioTable)
	
	local file = assert(io.open(NameFile, "w"))
	
	for i = 1, 255 do
		for j = 1, 255 do
			file:write(marioTable[i][j], " ")
		end
	end
	
	file:close()
	
end

function loadTable(NameFile)
	local index = 1
	local jndex = 1
	
	
	marioTable = {}
	for i = 1, 255 do
		marioTable[i] = {}
		for j = 1, 255 do
			marioTable[i][j] = 0
		end
	end
	
	
	local file = assert(io.open(NameFile, "r"))		
		for line in file:lines() do	
			for s in line:gmatch("%S+") do			
				marioTable[index][jndex] = tonumber(s)--+1
				jndex = jndex + 1
				if jndex > 255 then
					jndex = 1
					index = index + 1
				end
			end
		end
		
	file:close()	
	
end

function FreezeEnemyPositions()
    local xMem = 0x0213
    local yMem = 0x0214
    for i=1, 12 do
        --Use readbyte because we only read the lower half for position values
        memory.writebyte(xMem, 0x00FF)
        memory.writebyte(yMem, 0x00FF)
        xMem = xMem + 0x0010
        yMem = yMem + 0x0010
    end
end


function CalculateReward()
	-- Hobbs Cheating Heursitic
	-- Floor 1 Right 204
	-- Floor 2 Left 176
	-- Floor 3 Right 146
	-- Floor 4 Left 116
	-- Floor 5 Right 86
	-- Floor 6 Left 56
	local tempX=0
	
	if (marioY > 176) or (marioY > 116 and marioY <= 146) or (marioY > 56 and marioY <= 86) then --Incline right
		tempX = marioX
	elseif (marioY > 146 and marioY <= 176) or (marioY > 86 and marioY <= 116) or ( marioY <= 56) then --Incline left
		tempX = -1*marioX
	else
		tempX = marioX
	end
	
	local Reward = 1000 + (-4*marioY)+(tempX)
	
	
	--End state
	if(marioX ==145 and marioY == 28) then
		finished =true
		Reward = 13337
	end
	
	return Reward
end
	
	
function DoNextBestMove(marioXer,marioYer)

	local rewards = { Up = tableUp[marioYer][marioXer], Left = tableLeft[marioYer][marioXer], Right = tableRight[marioYer][marioXer]}
	local key = next(rewards)
	local max = rewards[key]

	for k, v in pairs(rewards) do
		if rewards[k] > max then
			key, max = k, v
		end
	end
	if (max == 0) then
	
	-- ANTI-LOST AI (IF PATH ISN'T FOUND TRY THIS HEURISTIC SEARCH)
		
		if(marioY > 120) then
		if (marioX > 125) then
			doMove("Left")
		else
			doMove("Right")
		end
		else
		if (marioX > 145) then
			doMove("Left")
		else
			doMove("Right")
		end
		end
	
	
	else
	doMove(key)
	end
	emu.frameadvance()
	clearMove()

	

end	
	
	
function ChooseBestMoveOrBackPropagate(marioXer,marioYer)
	
	local rewards = { Up = tableUp[marioYer][marioXer], Left = tableLeft[marioYer][marioXer], Right = tableRight[marioYer][marioXer]}
	
	local key = next(rewards)
	local max = rewards[key]

	for k, v in pairs(rewards) do
		if rewards[k] > max then
			key, max = k, v
		end
	end
	
	
	-- print(rewards)
	-- print("BEST ACTION = " .. key .. max)
	
	if max ~=-1 then --CHOOSING BEST ACTION
		
		if(key == "Up") then
		backPropagateStack[#backPropagateStack+1]={X=marioXer,Y=marioYer,A="Up"}
		Filename = "Up/".. marioXer .. "_" .. marioYer .. ".state"
		
		elseif(key == "Left") then
		backPropagateStack[#backPropagateStack+1]={X=marioXer,Y=marioYer,A="Left"}
		Filename = "Left/".. marioXer .. "_" .. marioYer .. ".state"
		
		elseif(key == "Right") then
		backPropagateStack[#backPropagateStack+1]={X=marioXer,Y=marioYer,A="Right"}
		Filename = "Right/".. marioXer .. "_" .. marioYer .. ".state"
		end
		-- for i,v in ipairs(backPropagateStack) do print(i,v) end
		
	else --BACK PROPAGATE IF IT IS A DEAD END

		Actioner = backPropagateStack[#backPropagateStack]["A"]
		-- print("Actioner =" .. Actioner)
		if(Actioner == "Up") then
		tableUp[backPropagateStack[#backPropagateStack]["Y"]][backPropagateStack[#backPropagateStack]["X"]] = -1
		saveTable("QtableUp.txt",tableUp)
		Filename = "Up/".. backPropagateStack[#backPropagateStack]["X"] .. "_" .. backPropagateStack[#backPropagateStack]["Y"] .. ".state"

		
		elseif(Actioner == "Left") then
		tableLeft[backPropagateStack[#backPropagateStack]["Y"]][backPropagateStack[#backPropagateStack]["X"]] = -1
		saveTable("QtableLeft.txt",tableLeft)
		Filename = "Left/".. backPropagateStack[#backPropagateStack]["X"] .. "_" .. backPropagateStack[#backPropagateStack]["Y"] .. ".state"

		
		elseif(Actioner == "Right") then
		tableRight[backPropagateStack[#backPropagateStack]["Y"]][backPropagateStack[#backPropagateStack]["X"]] = -1
		saveTable("QtableRight.txt",tableRight)
		Filename = "Right/".. backPropagateStack[#backPropagateStack]["X"] .. "_" .. backPropagateStack[#backPropagateStack]["Y"] .. ".state"
		
		end
		
		print("BACK PROPAGATING TO " .. backPropagateStack[#backPropagateStack]["X"] .. "_" .. backPropagateStack[#backPropagateStack]["Y"])
		table.remove(backPropagateStack,#backPropagateStack)
	
	end
	
end


function QLearnFromCurrentPosition(marioXer,marioYer)
 -- END = 145,28
	SaveName = "State/".. marioXer .. "_" .. marioYer .. ".state"
	savestate.save(SaveName)
	local LastMarioX = marioXer
	local LastMarioY = marioYer
	
	
	--Up
	loadTable("QtableUp.txt")
	tableUp = marioTable
	if(tableUp[marioYer][marioXer] == 0) then
		savestate.load(SaveName)
		i=0
		local breaker = false
		while i<maxIdleFrame do
			 FreezeEnemyPositions()
			 displayText ="MarioX Coordinate =" .. LastMarioX .. " " .. "MarioY Coordinate =" .. marioYer .. "Current Testing : Up"
			 gui.text(150,100,displayText,white)
			 doMove("Up")
			 emu.frameadvance()
			 clearMove()
			 GetMarioPosition()
			 i=i+1

			 if (marioX ~= LastMarioX or marioY ~= LastMarioY or marioStat == 255 or marioStat == 8) and (marioStat ~=4) then
				-- print("MARIO X" .. marioX .. " " .. "MARIO Y" .. marioY .. " " .. "LASTMARIO X" .. LastMarioX .. " " .. "MARIO Y" .. LastMarioY .. " ")
				
				if (marioStat ~= 255 and marioStat ~= 8) then -- If not dead or fell
					tableUp[LastMarioY][LastMarioX] = CalculateReward()
				else
					tableUp[LastMarioY][LastMarioX] = -1
				end
				-- print(tableUp[LastMarioY][LastMarioX])
				saveTable("QtableUp.txt",tableUp)
				SaveName2 = "Up/".. LastMarioX .. "_" .. LastMarioY .. ".state"
				savestate.save(SaveName2)
				breaker = true
				break
			 end
		end
		--Max frame reached, nothing happened
		if(breaker == false) then
			--If nothing happened
			tableUp[LastMarioY][LastMarioX] = -1

			saveTable("QtableUp.txt",tableUp)
			SaveName2 = "Up/".. LastMarioX .. "_" .. LastMarioY .. ".state"
			savestate.save(SaveName2)
		end
	end
	
	
	--Left
	loadTable("QtableLeft.txt")
	tableLeft = marioTable
	if(tableLeft[marioYer][marioXer] == 0) then
		savestate.load(SaveName)
		i=0
		local breaker = false
		while i<maxIdleFrame do
			 FreezeEnemyPositions()
			 displayText ="MarioX Coordinate =" .. LastMarioX .. " " .. "MarioY Coordinate =" .. marioYer .. "Current Testing : Left"
			 gui.text(150,100,displayText,white)
			 doMove("Left")
			 emu.frameadvance()
			 clearMove()
			 GetMarioPosition()
			 i=i+1

			 if (marioX ~= LastMarioX or marioY ~= LastMarioY or marioStat == 255 or marioStat == 8) and (marioStat ~=4) then
				-- print("MARIO X" .. marioX .. " " .. "MARIO Y" .. marioY .. " " .. "LASTMARIO X" .. LastMarioX .. " " .. "MARIO Y" .. LastMarioY .. " ")
				
				if (marioStat ~= 255 and marioStat ~= 8) then -- If not dead or fell
					tableLeft[LastMarioY][LastMarioX] = CalculateReward()
				else
					tableLeft[LastMarioY][LastMarioX] = -1
				end
				-- print(tableLeft[LastMarioY][LastMarioX])
				saveTable("QtableLeft.txt",tableLeft)
				SaveName2 = "Left/".. LastMarioX .. "_" .. LastMarioY .. ".state"
				savestate.save(SaveName2)
				breaker = true
				break
			 end
		end
		--Max frame reached, nothing happened
		if(breaker == false) then
			--If nothing happened
			tableLeft[LastMarioY][LastMarioX] = -1

			saveTable("QtableLeft.txt",tableLeft)
			SaveName2 = "Left/".. LastMarioX .. "_" .. LastMarioY .. ".state"
			savestate.save(SaveName2)
		end
	end
	
	--Right
	loadTable("QtableRight.txt")
	tableRight = marioTable
	if(tableRight[marioYer][marioXer] == 0) then
		savestate.load(SaveName)
		i=0
		local breaker = false
		while i<maxIdleFrame do
			 FreezeEnemyPositions()
			 displayText ="MarioX Coordinate =" .. LastMarioX .. " " .. "MarioY Coordinate =" .. marioYer .. "Current Testing : Right"
			 gui.text(150,100,displayText,white)
			 doMove("Right")
			 emu.frameadvance()
			 clearMove()
			 GetMarioPosition()
			 i=i+1

			 if (marioX ~= LastMarioX or marioY ~= LastMarioY or marioStat == 255 or marioStat == 8) and (marioStat ~=4) then
				-- print("MARIO X" .. marioX .. " " .. "MARIO Y" .. marioY .. " " .. "LASTMARIO X" .. LastMarioX .. " " .. "MARIO Y" .. LastMarioY .. " ")
				
				if (marioStat ~= 255 and marioStat ~= 8) then -- If not dead or fell
					tableRight[LastMarioY][LastMarioX] = CalculateReward()
				else
					tableRight[LastMarioY][LastMarioX] = -1
				end
				-- print(tableRight[LastMarioY][LastMarioX])
				saveTable("QtableRight.txt",tableRight)
				SaveName2 = "Right/".. LastMarioX .. "_" .. LastMarioY .. ".state"
				savestate.save(SaveName2)
				breaker = true
				break
			 end
		end
		--Max frame reached, nothing happened
		if(breaker == false) then
			--If nothing happened
			tableRight[LastMarioY][LastMarioX] = -1

			saveTable("QtableRight.txt",tableRight)
			SaveName2 = "Right/".. LastMarioX .. "_" .. LastMarioY .. ".state"
			savestate.save(SaveName2)
		end
	end
	


end








tableUpLeft = {}
tableUp = {}
tableUpRight = {}
tableLeft = {}
tableNothing = {}
tableRight = {}
tableDown = {}
backPropagateStack = {{}}

-- loadTable("QtableUpLeft.txt")
-- tableUpLeft = marioTable
-- loadTable("QtableUp.txt")
-- tableUp = marioTable
-- loadTable("QtableUpRight.txt")
-- tableUpRight = marioTable
-- loadTable("QtableLeft.txt")
-- tableLeft = marioTable
-- loadTable("QtableNothing.txt")
-- tableNothing = marioTable
-- loadTable("QtableRight.txt")
-- tableRight = marioTable
-- loadTable("QtableDown.txt")
-- tableDown = marioTable


Filename = "START.state"


-- Action
loadTable("QtableLeft.txt")
tableLeft = marioTable
loadTable("QtableRight.txt")
tableRight = marioTable
loadTable("QtableUp.txt")
tableUp = marioTable
-- savestate.load(Filename)

--Main loop
while true do
	
	-- -- Training
	-- if(finished==false) then
	-- print(Filename)
	-- savestate.load(Filename)
	-- GetMarioPosition()
	-- QLearnFromCurrentPosition(marioX,marioY)
	-- savestate.load(Filename)
	-- GetMarioPosition()
	-- ChooseBestMoveOrBackPropagate(marioX,marioY)
	-- else
	-- break
	-- end
	
	-- Action
	GetMarioPosition()
	DoNextBestMove(marioX,marioY)





	-- GetMarioPosition()
	-- GetEnemyPositions()
	-- clearMove()
	-- CalculateNextMove(marioXGrid,marioYGrid)
	-- doMove("Up-Right")
	 displayText ="MarioX Coordinate =" .. marioX .. " " .. "MarioY Coordinate =" .. marioY .. "Mario STAT =" .. marioStat
	 gui.text(150,100,displayText,white)
	-- clearMove()
	-- emu.frameadvance()
end